# 招生宣传合规预审输出模板

```json
{
  "contract_version": "1.2.0",
  "product_id": "JLZ-EDU-SK-082",
  "status": "completed | completed_with_limits | needs_input | needs_confirmation | failed",
  "status_reason": "具体状态原因",
  "summary": "结论摘要",
  "deliverables": {},
  "evidence": [],
  "assumptions": [],
  "open_questions": [],
  "human_review": {"required": false, "review_points": [], "confirmed": false},
  "errors": [],
  "next_action": "下一步"
}
```

### 合规风险表

| 项目 | 内容 |
|---|---|
| 结论/条目 |  |
| 依据/来源 |  |
| 风险与限制 |  |
| 下一步/责任人 |  |

### 问题原文与原因

| 项目 | 内容 |
|---|---|
| 结论/条目 |  |
| 依据/来源 |  |
| 风险与限制 |  |
| 下一步/责任人 |  |

### 可保留表达

| 项目 | 内容 |
|---|---|
| 结论/条目 |  |
| 依据/来源 |  |
| 风险与限制 |  |
| 下一步/责任人 |  |

### 建议改写版

| 项目 | 内容 |
|---|---|
| 结论/条目 |  |
| 依据/来源 |  |
| 风险与限制 |  |
| 下一步/责任人 |  |

### 缺失证据清单

| 项目 | 内容 |
|---|---|
| 结论/条目 |  |
| 依据/来源 |  |
| 风险与限制 |  |
| 下一步/责任人 |  |

### 发布前审批单

| 项目 | 内容 |
|---|---|
| 结论/条目 |  |
| 依据/来源 |  |
| 风险与限制 |  |
| 下一步/责任人 |  |

## Agent附加字段

仅在Agent中使用：

```json
{
  "agent_state": {},
  "stage_result": {
    "stage_id": "S6_FINAL_DELIVERY",
    "outcome": "completed",
    "next_stage": "S6_FINAL_DELIVERY",
    "recovery_required": false,
    "stage_notes": "阶段结果"
  }
}
```
